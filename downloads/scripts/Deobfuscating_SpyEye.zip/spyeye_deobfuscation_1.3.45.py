﻿'''
    SpyEye 1.3.45 Deobfuscation Script
    Copyright (c) 2011 Takahiro Haruyama

    Configration:
        for 1st deobfuscation: Set base_path.
        for 2nd deobfuscation: Set decode_function_name.
        for finding folder/mutex name: Nothing. But don't forget to load resource data in IDA Pro.
'''

decode_function_name = 'function_name_for_2nd_obfuscation'
base_path = 'path_to_names_to_resolve_folder'

process_list = ['System', 'system', 'smss.exe', 'csrss.exe', 'services.exe', 'explorer.exe', 'Explorer.exe']

def xor_decode(line_to_comment, start_addr, data_len):
    print '0x%x %d' % (start_addr, data_len)
    key = 0x4C
    count = data_len - 1

    while count != 0:
        dl = Byte(start_addr + count)
        dl = dl ^ key
        dl -= Byte(start_addr + count - 1)
        if dl >= 0:
            PatchByte(start_addr + count, dl)
        else:
            PatchByte(start_addr + count, 0x100 + dl)
        count -= 1

    decoded_str = GetString(start_addr, data_len)
    MakeComm(line_to_comment, 'getting string "%s"' % decoded_str)

def find_and_xor(line_to_comment, decode_func, index_key):

    ea = FindText(decode_func, SEARCH_DOWN|SEARCH_CASE, 0, 0, 'xor     edi, edi')
    ea = NextHead(ea, 0x7fffffff)
    key_array_addr = GetOperandValue(ea, 1)

    index = -1
    for i in range(4):
        if index_key == Dword(key_array_addr + 4 * i):
            index = i
    if index != -1:
        ea = FindText(decode_func, SEARCH_DOWN|SEARCH_CASE, 0, 0, 'mov     eax, [esi]')
        prev = PrevHead(ea, 0)
        len_array_addr = GetOperandValue(prev, 1)
        next = NextHead(ea, 0x7fffffff)
        data_base_addr = GetOperandValue(next, 1)
        data_len = Dword(len_array_addr + 4 * index)
        data_start_addr = data_base_addr + index * 0x30
        xor_decode(line_to_comment, data_start_addr, data_len)

def hash_function_name(name, bits, width):
    digest = 0
    for i in range(0, len(name)):
        digest = (digest << bits & 0xffffffff) | (digest >> (width - bits))
        digest = digest ^ ord(name[i])
    return digest

def comment_to_call(ea, func_name):
    end_ea = GetFunctionAttr(ea, FUNCATTR_END)
    val = min(20, end_ea - ea)
    call_ea = FindText(ea, SEARCH_DOWN|SEARCH_CASE, val, 0, "call    eax")
    if call_ea != BADADDR:
        print "The function name comment is inserted to call instruction at 0x%x" % call_ea
        MakeComm(call_ea, '%s' % func_name)

def generate_hash_map(filename):
    f = open(base_path + filename, "r")
    return dict((hash_function_name(func_name.rstrip('\t\r\n'), 7, 32), func_name.rstrip('\t\r\n')) for func_name in f)

def main():

    print '\n1st: decoding strings\n'

    decode_func = LocByName(decode_function_name)
    if decode_func == BADADDR:
        print '%s: no such name' % decode_function_name
        return
    refs = CodeRefsTo(decode_func, False)

    index_list = []
    for ref in refs:
        if GetMnem(ref) == 'call':
            while GetMnem(ref) != 'push':
                ref = FindCode(ref, SEARCH_UP)
            index_key = GetOperandValue(ref, 0)
            if index_key < 10000:
                while GetMnem(ref) != 'mov':
                    ref = FindCode(ref, SEARCH_UP)
                index_key = GetOperandValue(ref, 1)
            if not index_key in index_list:
                index_list.append(index_key)
                find_and_xor(ref, decode_func, index_key)

    print '\n2nd: resolving hashes\n'

    kernel32_hash_map = generate_hash_map('xp_sp3_kernel32.txt')
    ntdll_hash_map = generate_hash_map('xp_sp3_ntdll.txt')
    advapi32_hash_map = generate_hash_map('xp_sp3_advapi32.txt')
    wininet_hash_map = generate_hash_map('xp_sp3_wininet.txt')
    ws2_32_hash_map = generate_hash_map('xp_sp3_ws2_32.txt')
    plugin_hash_map = generate_hash_map('plugin_export.txt')
    process_hash_map = dict((hash_function_name(process, 7, 32), process) for process in process_list)
    config_bin_file_hash_map = generate_hash_map('filenames_in_config_bin.txt')

    ea = idaapi.get_imagebase()
    #print "\nSearch starts from 0x%x...\n" % (ea)
    while ea != BADADDR:
        #ea = FindText(ea, SEARCH_DOWN|SEARCH_CASE|SEARCH_REGEX, 0, 0, "push    ........h")
        ea = FindText(ea, SEARCH_DOWN|SEARCH_CASE|SEARCH_REGEX, 0, 0, "........h")
        if ea == BADADDR:
            break
        op = GetMnem(ea)
        digest = 0
        if op == "push":
            digest = GetOperandValue(ea, 0)
        elif op == "mov" or op == "cmp":
            digest = GetOperandValue(ea, 1)

        # resolve library function names
        if digest in kernel32_hash_map:
            print "Hit: \'%s\' (kernel32!%s) at 0x%x" % (GetDisasm(ea), kernel32_hash_map[digest], ea)
            MakeComm(ea, 'kernel32!%s' % kernel32_hash_map[digest])
            comment_to_call(ea, kernel32_hash_map[digest])
        elif digest in ntdll_hash_map:
            print "Hit: \'%s\' (ntdll!%s) at 0x%x" % (GetDisasm(ea), ntdll_hash_map[digest], ea)
            MakeComm(ea, 'ntdll!%s' % ntdll_hash_map[digest])
            comment_to_call(ea, ntdll_hash_map[digest])
        elif digest in advapi32_hash_map:
            print "Hit: \'%s\' (advapi32!%s) at 0x%x" % (GetDisasm(ea), advapi32_hash_map[digest], ea)
            MakeComm(ea, 'advapi32!%s' % advapi32_hash_map[digest])
            comment_to_call(ea, advapi32_hash_map[digest])
        elif digest in wininet_hash_map:
            print "Hit: \'%s\' (wininet!%s) at 0x%x" % (GetDisasm(ea), wininet_hash_map[digest], ea)
            MakeComm(ea, 'wininet!%s' % wininet_hash_map[digest])
            comment_to_call(ea, wininet_hash_map[digest])
        elif digest in ws2_32_hash_map:
            print "Hit: \'%s\' (ws2_32!%s) at 0x%x" % (GetDisasm(ea), ws2_32_hash_map[digest], ea)
            MakeComm(ea, 'ws2_32!%s' % ws2_32_hash_map[digest])
            comment_to_call(ea, ws2_32_hash_map[digest])
        # resolve export function names of plugins
        elif digest in plugin_hash_map:
            print "Hit: \'%s\' (plugin!%s) at 0x%x" % (GetDisasm(ea), plugin_hash_map[digest], ea)
            MakeComm(ea, 'plugin!%s' % plugin_hash_map[digest])
        # resolve process names for code injection
        elif digest in process_hash_map:
            print "Hit: \'%s\' process name: %s at 0x%x" % (GetDisasm(ea), process_hash_map[digest], ea)
            MakeComm(ea, '%s' % process_hash_map[digest])
        # resolve file names included in config.bin
        elif digest in config_bin_file_hash_map:
            print "Hit: \'%s\' file name in config.bin: %s at 0x%x" % (GetDisasm(ea), config_bin_file_hash_map[digest], ea)
            MakeComm(ea, '%s' % config_bin_file_hash_map[digest])

        ea = NextHead(ea, 0x7fffffff)

    print "\nAppendix: find install folder name / mutex name\n"

    ea = idaapi.get_imagebase()
    while ea != BADADDR:
        ea = FindBinary(ea, SEARCH_DOWN, '21 45 59 45') # '!EYE' signature of C1 resource
        if ea == BADADDR:
            break
        str_config_bin = GetString(ea + 0x21c)
        if str_config_bin == 'config.bin':
            folder_name = GetString(ea + 0x20c)
            mutex_name = GetString(ea + 0x390)
            print 'folder name = %s, mutex name = %s' % (folder_name, mutex_name)
        ea = NextHead(ea, 0x7fffffff)

if __name__ == '__main__':
    main()
