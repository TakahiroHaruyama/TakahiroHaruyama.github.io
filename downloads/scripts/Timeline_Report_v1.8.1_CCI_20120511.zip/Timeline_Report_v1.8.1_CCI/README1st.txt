This EnScript is the modified version of Timeline Report EnScript provided by Geoff Black. This version makes a timeline using not only Standard Information (SI) Attribute timestamps but also Filename (FN) Attribute timestamps.
Please cotact the following persion if there is any question or request about the modification.

Takahiro Haruyama, EnCE
Internet Initiative Japan Inc.
http://cci.cocolog-nifty.com/blog/

Enjoy ;-)
