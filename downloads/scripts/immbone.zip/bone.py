# bone - Immunity Debugger script for setting memory breakpoints on execution
# Copyright (c) 2011 Takahiro Haruyama
# This script is the ID port of ollybone written by Joe Stewart

import immlib
from libevent import ExceptionEvent
import debugger

import os
import ctypes
from ctypes import wintypes, windll, byref

advapi32 = windll.advapi32
kernel32 = windll.kernel32

driver_name = 'immbone.sys'
driver_label = 'immbone'
device_name = "\\\\.\\Global\\%s" % driver_label

INVALID_HANDLE_VALUE = -1

SC_MANAGER_ALL_ACCESS = 0xf003f

SERVICE_ALL_ACCESS = 0xf01ff
SERVICE_KERNEL_DRIVER = 0x00000001
SERVICE_DEMAND_START = 0x00000003
SERVICE_ERROR_NORMAL = 0x00000001
SERVICE_CONTROL_STOP = 0x00000001

GENERIC_READ = 0x80000000
GENERIC_WRITE = 0x40000000
OPEN_EXISTING = 0x3
FILE_ATTRIBUTE_NORMAL = 0x80

FILE_DEVICE_IMMBONE = 0x0000584f
METHOD_BUFFERED = 0
FILE_ANY_ACCESS = 0
FILE_READ_ACCESS = 1
FILE_WRITE_ACCESS = 2

class OSVERSIONINFOEX(ctypes.Structure):
    _fields_ = [("dwOSVersionInfoSize", wintypes.DWORD),
                ("dwMajorVersion", wintypes.DWORD),
                ("dwMinorVersion", wintypes.DWORD),
                ("dwBuildNumber", wintypes.DWORD),
                ("dwPlatformId", wintypes.DWORD),
                ("szCSDVersion", ctypes.c_char * 128),
                ("wServicePackMajor", wintypes.WORD),
                ("wServicePackMinor", wintypes.WORD),
                ("wSuiteMask", wintypes.WORD),
                ("wProductType", wintypes.BYTE),
                ("wReserved", wintypes.BYTE),
                ]

class SERVICE_STATUS(ctypes.Structure):
    _fields_ = [("dwServiceType", wintypes.DWORD),
                ("dwCurrentState", wintypes.DWORD),
                ("dwControlsAccepted", wintypes.DWORD),
                ("dwWin32ExitCode", wintypes.DWORD),
                ("dwServiceSpecificExitCode", wintypes.DWORD),
                ("dwCheckPoint", wintypes.DWORD),
                ("dwWaitHint", wintypes.DWORD),
                ]

class IOCTL_SET_PARAMS(ctypes.Structure):
    _fields_ = [("pid", wintypes.DWORD),
                ("va", wintypes.DWORD),
                ("size", wintypes.DWORD),
                ]

class IOCTL_STATUS_PARAMS(ctypes.Structure):
    _fields_ = [("section_list", IOCTL_SET_PARAMS * 256),
                ("last_section", ctypes.c_int),
                ]

imm = immlib.Debugger()

class ctrl_bone():

    def CTL_CODE(DeviceType, Function, Method, Access):
        return ((DeviceType) << 16) | ((Access) << 14) | ((Function) << 2) | (Method)

    IOCTL_IMMBONE_SET = CTL_CODE(FILE_DEVICE_IMMBONE, 0x01, METHOD_BUFFERED, FILE_ANY_ACCESS)
    IOCTL_IMMBONE_RESTORE = CTL_CODE(FILE_DEVICE_IMMBONE, 0x02, METHOD_BUFFERED, FILE_ANY_ACCESS)
    IOCTL_IMMBONE_STATUS = CTL_CODE(FILE_DEVICE_IMMBONE, 0x03, METHOD_BUFFERED, FILE_ANY_ACCESS)

    def __init__ (self):
        self.set_params = IOCTL_SET_PARAMS()
        self.bnum = 0
        self.status_params = IOCTL_STATUS_PARAMS()
        self.status_params.last_section = -1

    def prevent_paged_out(self, va, size):
        for page_addr in range(va, va + size, 4096):
            tmp = imm.readMemory(page_addr, 4)
        return

    def get_device_handle(self):
        return kernel32.CreateFileA(device_name, GENERIC_READ | GENERIC_WRITE, 0, None, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, None)

    def check_loaded_driver(self):
        h_device = self.get_device_handle()

        if h_device == INVALID_HANDLE_VALUE:
            return False
        else:
            kernel32.CloseHandle(h_device)
            return True

    def check_version(self):
        # support only 2k/XP/2003
        wh = {(2, 5,  0): "2000",
              (2, 5,  1): "XP"  ,
              (2, 5,  2): "2003",
              }

        o = OSVERSIONINFOEX()
        o.dwOSVersionInfoSize = 156 # sizeof(OSVERSIONINFOEX)

        kernel32.GetVersionExA(byref(o))
        wk = (o.dwPlatformId, o.dwMajorVersion, o.dwMinorVersion)

        if wh.has_key(wk):
            return True
        else:
            return False

    def load_device_driver(self, driver_path):
        sc_handle_manager = advapi32.OpenSCManagerA(None, None, SC_MANAGER_ALL_ACCESS)
        sc_handle_service = advapi32.OpenServiceA(sc_handle_manager, driver_label, SERVICE_ALL_ACCESS)

        if sc_handle_service != None:
            status = SERVICE_STATUS()
            advapi32.ControlService(sc_handle_service, SERVICE_CONTROL_STOP, byref(status))
            advapi32.DeleteService(sc_handle_service)
            advapi32.CloseServiceHandle(sc_handle_service)

        sc_handle_service = advapi32.CreateServiceA(sc_handle_manager, driver_label, driver_label, SERVICE_ALL_ACCESS,
                    SERVICE_KERNEL_DRIVER, SERVICE_DEMAND_START, SERVICE_ERROR_NORMAL, driver_path, None, None, None, None, None)

        if sc_handle_service == None:
            imm.log("Error: cannot get the service handle (error code is %d)" % kernel32.GetLastError())
            return False
        if advapi32.StartServiceA(sc_handle_service, 0, None) == 0:
            #self.unload_device_driver() # removing the service
            #if advapi32.StartServiceA(sc_handle_service, 0, None) == 0:
            imm.log("Error: cannot start the service (error code is %d)" % kernel32.GetLastError())
            return False

        advapi32.CloseServiceHandle(sc_handle_service)
        advapi32.CloseServiceHandle(sc_handle_manager)
        return True

    def unload_device_driver(self):
        #if not check_loaded_driver():
        #    imm.log("Error: The driver is not loaded.")
        #    return False

        sc_handle_manager = advapi32.OpenSCManagerA(None, None, SC_MANAGER_ALL_ACCESS)
        sc_handle_service = advapi32.OpenServiceA(sc_handle_manager, driver_label, SERVICE_ALL_ACCESS)
        if sc_handle_service == None:
            imm.log("Error: cannot get the service handle (error code is %d)" % kernel32.GetLastError())
            return False

        if advapi32.DeleteService(sc_handle_service) == 0:
            imm.log("Error: cannot delete the service of the driver (error code is %d)" % kernel32.GetLastError())
            return False

        advapi32.CloseServiceHandle(sc_handle_service)
        advapi32.CloseServiceHandle(sc_handle_manager)
        return True

    def init_driver(self):
        if not self.check_version():
            imm.log("Error: The OS is not supported.")
            return False

        if not self.check_loaded_driver():
            driver_path = os.getcwd() + '\\PyCommands\\' + driver_name
            if self.load_device_driver(driver_path):
                imm.log("The device driver is loaded")

        if not self.check_loaded_driver():
            imm.log("Error: The driver cannot be opened")
            return False

        return True

    def set_break_on_execute(self):
        bytes_read = wintypes.DWORD()

        h_device = self.get_device_handle()
        self.prevent_paged_out(self.set_params.va, self.set_params.size)
        if kernel32.DeviceIoControl(h_device, self.IOCTL_IMMBONE_SET, byref(self.set_params), 12, None, 0, byref(bytes_read), None) == 0:
            imm.log("Error: setting the memory breakpoint failed. (error code is %d)" % kernel32.GetLastError())
            kernel32.CloseHandle(h_device)
            return False

        kernel32.CloseHandle(h_device)
        return True

    def unset_break_on_execute(self):
        bytes_read = wintypes.DWORD()

        h_device = self.get_device_handle()
        if kernel32.DeviceIoControl(h_device, self.IOCTL_IMMBONE_RESTORE, byref(self.bnum), 4, None, 0, byref(bytes_read), None) == 0:
            imm.log("Error: unsetting the memory breakpoint failed. (error code is %d)" % kernel32.GetLastError())
            kernel32.CloseHandle(h_device)
            return False

        kernel32.CloseHandle(h_device)
        return True

    def get_status_info(self):
        bytes_read = wintypes.DWORD()

        if not self.check_loaded_driver():
            return
        h_device = self.get_device_handle()
        if kernel32.DeviceIoControl(h_device, self.IOCTL_IMMBONE_STATUS, None, 0, byref(self.status_params), 12 * 256 + 4, byref(bytes_read), None) == 0:
            imm.log("Error: getting the memory breakpoint status failed. (error code is %d)" % kernel32.GetLastError())
            kernel32.CloseHandle(h_device)
            return

        kernel32.CloseHandle(h_device)
        return

    def get_break_on_execute_status(self):
        self.get_status_info()
        section_list = self.status_params.section_list
        last_section = self.status_params.last_section

        for i in range(0, last_section + 1):
            section = section_list[i]
            imm.log("[0x%x] 0x%08x - 0x%08x (pid:%d)" % (i+1, section.va, section.va + section.size, section.pid), focus = 1)

        return

class hook_ss(immlib.AllExceptHook):

   def __init__(self):
       immlib.AllExceptHook.__init__(self)

   def run(self, regs):
       imm = immlib.Debugger()

       try:
        evento = imm.getEvent()
       except TypeError:
        #imm.ignoreSingleStep(flag="CONTINUE")
        return

       else:
        pid = imm.getDebuggedPid()
        cb = ctrl_bone()
        cb.get_status_info()
        section_list = cb.status_params.section_list
        last_section = cb.status_params.last_section
        if last_section == -1:
            self.UnHook()
            #imm.ignoreSingleStep(flag="CONTINUE")
            return

        if evento:
            if isinstance(evento, ExceptionEvent):
                if evento.Exception[0].getType() == "SingleStep":
                    ea = evento.Exception[0].ExceptionAddress
                    for i in range(0, last_section + 1):
                        section = section_list[i]
                        if section.pid == pid and section.va <= ea <= section.va + section.size:
                            #imm.ignoreSingleStep(flag="DISABLE")
                            imm.log("break on execute at 0x%08x" % ea, focus = 1)
                            return

class hook_exit(immlib.ExitProcessHook):

   def __init__(self):
       immlib.ExitProcessHook.__init__(self)

   def run(self, regs):
    #imm.log("exit process hook")
    debugger.remove_hook("hooking_single_step_by_bone")
    #imm.ignoreSingleStep(flag="CONTINUE")

def find_section(addr):

    imm.getMemoryPages()
    start = 0

    for a in imm.MemoryPages.keys():
        mem = imm.MemoryPages[a]
        start = mem.getBaseAddress()

        if start == addr:
            size  = mem.getSize()
            return start, size

    return 0, 0

def main(args):
    cb = ctrl_bone()
    s = hook_ss()
    e = hook_exit()

    if len(args) == 1 and args[0] == 'status':
        imm.log("break on execute status: ")
        cb.get_break_on_execute_status()

    elif len(args) == 2:
        (cmd, arg) = args

        if cmd == 'remove' and arg == 'driver':
            if cb.unload_device_driver():
                return "Done. The driver will be removed after reboot."

        elif cmd == 'set':
            addr = int(arg, 16)
            if addr < 0 or addr > 0xffffffff:
                return "Error: the VA should be 0-0xffffffff"
            start, size = find_section(addr)
            if start == 0:
                return "Error: the VA not found"
            else:
                imm.log("setting memory breakpoint on execute: start=0x%08x, end=0x%08x" % (start, start + size))
                if not cb.init_driver():
                    return "init_driver: failed."
                cb.set_params.pid = imm.getDebuggedPid()
                cb.set_params.va = start
                cb.set_params.size = size
                if not cb.set_break_on_execute():
                    return "set_break_on_execute: failed."
                e.add("hooking_process_exit_by_bone")
                s.add("hooking_single_step_by_bone")
                #imm.ignoreSingleStep(flag="DISABLE")

        elif cmd == 'unset':
            bnum_int = int(arg, 16)
            if bnum_int < 0 or bnum_int > 0x100:
                return "Error: the break number should be 0-256 (0 is all clear)"
            cb.bnum = ctypes.c_uint(bnum_int)
            imm.log("unsetting memory breakpoint on execute: break number [0x%x]" % cb.bnum.value)
            if not cb.init_driver():
                return "There is no break point (driver not loaded)"
            if not cb.unset_break_on_execute():
                return "unset_break_on_execute: failed."

        else:
            return "usage: !bone [ status | set start_VA | unset break_number | remove driver ]"

    else:
        return "usage: !bone [ status | set start_VA | unset break_number | remove driver ]"

    return "bone completed"

if __name__ == '__main__':
    print "This module is for use within Immunity Debugger only"
